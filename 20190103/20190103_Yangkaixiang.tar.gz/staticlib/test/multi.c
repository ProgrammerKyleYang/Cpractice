#include "multi.h"
#include <iostream>
int multi(int x, int y)
{
	return x*y;

}
