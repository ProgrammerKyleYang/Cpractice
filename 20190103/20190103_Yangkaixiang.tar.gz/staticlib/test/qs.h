#ifndef __QS_H_
#define __QS_H_

int qs(int,int,int);

#endif
