#include "multi.h"
#include <iostream>
using std::cout;
using std::endl;
int main(void)
{
	int a=5;
	int b=3;
cout <<"a="<<a<<" , "<<"b="<<b<<endl;
	cout<<"a * b = "<< multi(a,b)<<endl;
	return 0;
}

