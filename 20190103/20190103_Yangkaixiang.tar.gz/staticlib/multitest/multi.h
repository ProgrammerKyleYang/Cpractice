#ifndef __MULTI_H__
#define __MULTI_H__

int multi(int, int);

#endif
 
